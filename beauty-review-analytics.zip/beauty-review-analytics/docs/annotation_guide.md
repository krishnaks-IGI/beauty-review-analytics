# Proposed annotation guide

Assign each label independently; a review can have multiple positive labels. Label only what the text states or clearly implies. Do not infer diagnosis, ingredient causality, or objective product quality. If text is too short or unclear, select other_unclear and flag for adjudication.

- efficacy: reviewer describes an outcome or lack of outcome (for example, moisturizing or no visible effect).
- irritation_sensitivity: reviewer reports irritation, burning, redness, breakout, allergy-like language, or sensitivity. This is language triage, not diagnosis.
- texture_scent: feel, absorption, residue, consistency, fragrance, or scent.
- packaging: container, pump, leakage, breakage, seal, or usability.
- value: price, quantity, perceived worth, or comparison to cost.
- other_unclear: shipping, service, mixed or unclear content, or none of the above.

For each label, use 1=yes, 0=no, blank=not yet adjudicated. Double-label at least a subset, discuss disagreements, version the guide, and keep annotator notes separate from model inputs.
