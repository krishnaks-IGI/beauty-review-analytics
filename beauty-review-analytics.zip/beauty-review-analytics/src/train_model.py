"""Train multi-label TF-IDF logistic regression with product-group holdout."""
import argparse
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.multiclass import OneVsRestClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import classification_report
LABELS=['efficacy','irritation_sensitivity','texture_scent','packaging','value','other_unclear']
def main():
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--group-column',default='product_id'); a=p.parse_args()
    d=pd.read_csv(a.input); required=['combined_text',a.group_column]+LABELS
    missing=[c for c in required if c not in d]
    if missing: raise SystemExit('Missing required columns: '+', '.join(missing))
    d=d.dropna(subset=['combined_text',a.group_column]+LABELS)
    if d[a.group_column].nunique()<5: raise SystemExit('Need at least five distinct product groups for a basic grouped holdout.')
    splitter=GroupShuffleSplit(n_splits=1,test_size=.2,random_state=42)
    tr,te=next(splitter.split(d,d[LABELS],groups=d[a.group_column]))
    if d.iloc[tr][LABELS].sum().min()<2: raise SystemExit('Some labels have too few positive training examples; collect more reviewed labels.')
    model=Pipeline([('tfidf',TfidfVectorizer(ngram_range=(1,2),min_df=2,max_features=100000,sublinear_tf=True)),('clf',OneVsRestClassifier(LogisticRegression(max_iter=1000,class_weight='balanced')))])
    model.fit(d.iloc[tr]['combined_text'],d.iloc[tr][LABELS]); pred=model.predict(d.iloc[te]['combined_text'])
    print(classification_report(d.iloc[te][LABELS],pred,target_names=LABELS,zero_division=0))
    print('Scores are exploratory; review per-label support and grouped split limitations before use.')
if __name__=='__main__': main()
