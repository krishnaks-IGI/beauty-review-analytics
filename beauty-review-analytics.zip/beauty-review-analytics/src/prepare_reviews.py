"""Normalize Amazon Reviews 2023 JSONL; emits audit counts and CSV."""
import argparse, json
from pathlib import Path
import pandas as pd

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',required=True); ap.add_argument('--output',required=True)
    a=ap.parse_args(); rows=[]; malformed=0
    with open(a.input,encoding='utf-8') as f:
        for line in f:
            try: x=json.loads(line)
            except json.JSONDecodeError: malformed+=1; continue
            text=' '.join(str(x.get(k) or '').split() for k in [])
            title=' '.join(str(x.get('title') or '').split())
            body=' '.join(str(x.get('text') or '').split())
            combined=' '.join(v for v in [title,body] if v and v.casefold()!=title.casefold())
            try: rating=float(x.get('rating'))
            except (TypeError,ValueError): rating=None
            ts=x.get('timestamp')
            rows.append({'review_id':x.get('review_id'),'product_id':x.get('parent_asin') or x.get('asin'),'rating':rating,'title':title,'text':body,'combined_text':combined,'timestamp_ms':ts,'verified_purchase':x.get('verified_purchase'),'helpful_vote':x.get('helpful_vote')})
    df=pd.DataFrame(rows); input_rows=len(df)
    df['timestamp']=pd.to_datetime(df['timestamp_ms'],unit='ms',utc=True,errors='coerce')
    empty=df['combined_text'].fillna('').str.strip().eq(''); invalid_rating=~df['rating'].between(1,5,inclusive='both')
    exact_dupes=df.duplicated(subset=['review_id'],keep='first') if 'review_id' in df else pd.Series(False,index=df.index)
    df=df.loc[~empty & ~invalid_rating & ~exact_dupes].copy()
    out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True); df.to_csv(out,index=False)
    print(json.dumps({'parsed_rows':input_rows,'malformed_lines':malformed,'empty_text':int(empty.sum()),'invalid_rating':int(invalid_rating.sum()),'duplicate_review_ids':int(exact_dupes.sum()),'output_rows':len(df),'output':str(out)},indent=2))
if __name__=='__main__': main()
