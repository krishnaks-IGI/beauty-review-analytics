# Beauty Review Analytics

A reproducible Python project scaffold for organizing public beauty-product reviews into interpretable themes for analyst review. It is designed around the Amazon Reviews 2023 All_Beauty subset. No raw review data or reviewer identifiers are included in this repository.

## Evidence status

This is a prepared workflow, not a completed empirical analysis. The public source archive was not downloaded into this workspace, there are no human-created labels, and no model was trained. Do not treat planned metrics or thresholds as results.

## Project layout

- data/raw/ is for the source JSONL archive; keep it out of version control.
- data/processed/ is for generated clean files; keep it out of version control.
- src/prepare_reviews.py validates and normalizes JSONL records.
- src/train_model.py is a labeled-data training scaffold with grouped validation.
- docs/annotation_guide.md defines proposed multi-label themes and annotation rules.
- docs/source_manifest_template.json records provenance.
- reports/ contains the six internship reports and portal descriptions.

## Setup and use

Use Python 3.10 or newer. Install packages from requirements.txt in a virtual environment. Download the documented All_Beauty review JSONL from the dataset publisher and place it at data/raw/All_Beauty.jsonl. Then run: python src/prepare_reviews.py --input data/raw/All_Beauty.jsonl --output data/processed/reviews_clean.csv

After creating a reviewed label file with review_id and one binary column for each theme, train with: python src/train_model.py --input data/processed/labeled_reviews.csv --group-column product_id. The script requires enough distinct product groups and labels; otherwise it stops with an explanatory error.

## Responsible use

The themes describe review language, not objective product efficacy or medical diagnoses. Keep people in the loop, especially for irritation/sensitivity reports. The sample is self-selected and marketplace-specific; it is not representative of all consumers or India. Do not publish raw review text, user IDs, or personal information. Follow the dataset publisher terms and applicable platform policies.

## References

- McAuley Lab, Amazon Reviews 2023: https://amazon-reviews-2023.github.io/
- McKinsey & Company, State of Beauty 2025: https://www.mckinsey.com/industries/consumer-packaged-goods/our-insights/state-of-beauty-2025
- Ni, Li & McAuley (2019), EMNLP-IJCNLP: https://cseweb.ucsd.edu/~jmcauley/pdfs/emnlp19a.pdf
